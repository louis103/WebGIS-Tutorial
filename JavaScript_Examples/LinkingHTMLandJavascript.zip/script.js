let textHeading = document.getElementById("text");
let htmlButton = document.getElementById("btn1").addEventListener('click', executedFunction);


// create and initialize the executed function
function executedFunction(){
  alert("Now we are learning about linking HTML with JavaScript!");
  textHeading.innerHTML = "Button was clicked successfully...";
};